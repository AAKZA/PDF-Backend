Backend deployment instructions:
1. Upload to Render
2. Set STRIPE_SECRET_KEY and FRONTEND_SUCCESS_URL
